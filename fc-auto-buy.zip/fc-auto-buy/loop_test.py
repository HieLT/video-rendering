"""Repeated safe loop: open dialog, compare OCR price, then cancel."""
from __future__ import annotations
import argparse, subprocess, sys, time
from pathlib import Path

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--baseline-bp", type=int, default=7390000000)
    p.add_argument("--count", type=int, default=20)
    p.add_argument("--delay-ms", type=int, default=250)
    args = p.parse_args()
    probe = Path(__file__).with_name("flow_probe.py")
    for i in range(1, args.count + 1):
        print(f"iteration={i}/{args.count}", flush=True)
        cmd = [sys.executable, "-u", str(probe), "--open-dialog", "--cancel-after",
               "--buy-once", "--baseline-bp", str(args.baseline_bp)]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.stdout:
            print(result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr, flush=True)
        if "buy_sent=True" in result.stdout:
            print("one_shot_complete=True", flush=True)
            return 0
        if result.returncode == 1:
            print("stopping_on_timeout=True", flush=True)
            return 1
        if result.returncode != 0:
            return result.returncode
        time.sleep(args.delay_ms / 1000)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
