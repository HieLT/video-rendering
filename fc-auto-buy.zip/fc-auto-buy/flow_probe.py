"""Probe LIST -> BUY_DIALOG timing without submitting a purchase."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
import win32api
import win32con
import win32gui

from window_capture import capture_window, find_window
from price_reader import read_price


def crop(image, region):
    return image.crop((region["left"], region["top"],
                       region["left"] + region["width"],
                       region["top"] + region["height"]))


def digest(image):
    gray = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2GRAY)
    return cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)[1].tobytes()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--open-dialog", action="store_true",
                        help="click configured list buy button; never clicks purchase")
    parser.add_argument("--cancel-after", action="store_true",
                        help="after detecting the dialog, click the configured Cancel button")
    parser.add_argument("--baseline-bp", type=int, default=None,
                        help="only cancel when OCR price differs from this BP value")
    parser.add_argument("--buy-once", action="store_true",
                        help="send one buy click when price differs; stops immediately")
    parser.add_argument("--max-bp", type=int, default=None,
                        help="buy guard: detected price must be <= this BP")
    args = parser.parse_args()
    root = Path(__file__).parent
    cfg = json.loads((root / "regions.json").read_text(encoding="utf-8-sig"))
    hwnd = find_window(cfg.get("window_title", "FC ONLINE"))
    if hwnd is None:
        raise SystemExit("FC ONLINE window not found")
    if not args.open_dialog:
        print("LIST state detected; dry-run only. Pass --open-dialog to open the buy dialog.")
        return 0
    button = cfg["regions"].get("list_buy_button") or cfg["regions"].get("market_buy_button")
    if not button:
        raise SystemExit("market_buy_button is not calibrated")
    left, top, _, _ = win32gui.GetWindowRect(hwnd)
    x = left + button["left"] + button["width"] // 2
    y = top + button["top"] + button["height"] // 2
    before = capture_window(hwnd)
    started = time.perf_counter()
    # Prefer a window message so this also works when the game runs elevated
    # and Windows denies synthetic desktop cursor input.
    try:
        win32api.SetCursorPos((x, y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    except Exception:
        rel_x = button["left"] + button["width"] // 2
        rel_y = button["top"] + button["height"] // 2
        lparam = (rel_y << 16) | rel_x
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lparam)
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lparam)
    dialog = cfg["regions"].get("market_max_price")
    if not dialog:
        raise SystemExit("market_max_price is not calibrated")
    old = digest(crop(before, dialog))
    while time.perf_counter() - started < 3:
        current = capture_window(hwnd)
        if digest(crop(current, dialog)) != old:
            print(f"dialog_change_ms={(time.perf_counter() - started) * 1000:.1f}")
            # The first changed frame is often the dialog animation. Wait for
            # the final layout before taking the OCR sample.
            time.sleep(0.25)
            current = capture_window(hwnd)
            detected_bp = None
            if args.baseline_bp is not None:
                sample = crop(current, dialog).resize((680, 280))
                detected_text, detected_bp = read_price(sample)
                debug_path = Path(__file__).with_name("last_price_debug.png")
                sample.save(debug_path)
                print(f"detected_text={detected_text!r} detected_bp={detected_bp} baseline_bp={args.baseline_bp} debug={debug_path}")
            # Never treat an OCR failure as a price change. This is a hard
            # safety gate for the one-shot purchase mode.
            changed = detected_bp is not None and (args.baseline_bp is None or detected_bp != args.baseline_bp)
            allowed = args.max_bp is None or (detected_bp is not None and detected_bp <= args.max_bp)
            if args.buy_once and not changed:
                # Refresh cycle: unchanged price must close the dialog so the
                # caller can reopen it and request a fresh market snapshot.
                cancel = cfg["regions"].get("cancel_button")
                if cancel:
                    cx = cancel["left"] + cancel["width"] // 2
                    cy = cancel["top"] + cancel["height"] // 2
                    lp = (cy << 16) | cx
                    try:
                        win32api.SetCursorPos((left + cx, top + cy))
                        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                    except Exception:
                        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
                        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lp)
                    print("unchanged_price_cancelled=True")
                return 0
            if args.buy_once and changed and allowed:
                buy = cfg["regions"].get("buy_button")
                if not buy:
                    raise SystemExit("buy_button is not calibrated")
                bx = buy["left"] + buy["width"] // 2
                by = buy["top"] + buy["height"] // 2
                lp = (by << 16) | bx
                try:
                    win32api.SetCursorPos((left + bx, top + by))
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                except Exception:
                    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
                    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lp)
                print("buy_sent=True")
                return 0
            if args.cancel_after and changed:
                cancel = cfg["regions"].get("cancel_button")
                if not cancel:
                    raise SystemExit("cancel_button is not calibrated")
                cx = cancel["left"] + cancel["width"] // 2
                cy = cancel["top"] + cancel["height"] // 2
                lp = (cy << 16) | cx
                try:
                    win32api.SetCursorPos((left + cx, top + cy))
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                except Exception:
                    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
                    win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lp)
                print("cancel_sent=True")
            return 0
        time.sleep(0.05)
    print("dialog_change_timeout_ms=3000")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
