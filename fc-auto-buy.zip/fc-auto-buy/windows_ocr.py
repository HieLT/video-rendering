"""Windows built-in OCR adapter; avoids an external tesseract.exe install."""
from __future__ import annotations

import asyncio
from io import BytesIO

from PIL import Image
import re


async def recognize(image: Image.Image) -> str:
    from winrt.windows.graphics.imaging import BitmapDecoder
    from winrt.windows.media.ocr import OcrEngine
    from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream

    engine = OcrEngine.try_create_from_user_profile_languages()
    if engine is None:
        raise RuntimeError("Windows OCR language pack is unavailable")
    buf = BytesIO()
    image.convert("RGBA").save(buf, format="PNG")
    stream = InMemoryRandomAccessStream()
    writer = DataWriter(stream)
    writer.write_bytes(buf.getvalue())
    await writer.store_async()
    await writer.flush_async()
    stream.seek(0)
    decoder = await BitmapDecoder.create_async(stream)
    bitmap = await decoder.get_software_bitmap_async()
    result = await engine.recognize_async(bitmap)
    return " ".join(line.text for line in result.lines)


def recognize_sync(image: Image.Image) -> str:
    return asyncio.run(recognize(image))


def normalize_price(text: str) -> int | None:
    cleaned = re.sub(r"[^0-9BMK.,]", "", text.upper())
    if not cleaned:
        return None
    suffix = cleaned[-1] if cleaned[-1] in "BMK" else ""
    number = cleaned[:-1] if suffix else cleaned
    try:
        value = float(number if suffix else number.replace(".", "").replace(",", ""))
    except ValueError:
        return None
    return round(value * {"B": 1_000_000_000, "M": 1_000_000, "K": 1_000}.get(suffix, 1))
