"""Small-region price reader with Windows OCR and conservative validation."""
from __future__ import annotations

import cv2
import numpy as np
from PIL import Image

from windows_ocr import normalize_price, recognize_sync


def read_price(image: Image.Image) -> tuple[str, int | None]:
    gray = cv2.cvtColor(np.asarray(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
    variants = [gray,
                cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1],
                cv2.threshold(gray, 170, 255, cv2.THRESH_BINARY)[1]]
    candidates = []
    for variant in variants:
        prepared = Image.fromarray(cv2.resize(variant, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC))
        text = recognize_sync(prepared).strip()
        value = normalize_price(text)
        if value is not None:
            candidates.append((text, value))
    return max(candidates, key=lambda item: len(item[0])) if candidates else ("", None)
